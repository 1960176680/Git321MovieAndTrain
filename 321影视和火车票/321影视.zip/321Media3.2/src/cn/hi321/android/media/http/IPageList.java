package cn.hi321.android.media.http;

/**
 * page list接口
 * 
 * @author yangguangfu
 * 
 */
public interface IPageList {

}
