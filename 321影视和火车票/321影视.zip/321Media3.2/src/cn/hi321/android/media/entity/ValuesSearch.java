package cn.hi321.android.media.entity;

public class ValuesSearch {
    public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getTerm() {
		return term;
	}
	public void setTerm(String term) {
		this.term = term;
	}
	private String title;
    private String  term;
}
