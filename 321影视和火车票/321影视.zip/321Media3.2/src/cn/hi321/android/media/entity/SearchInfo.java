//package cn.hi321.android.media.entity;
//
//import java.util.ArrayList;
//
//import cn.hi321.android.media.http.Values;
//
//public class SearchInfo {
//
//	public String getSort() {
//		return sort;
//	}
//
//	public void setSort(String sort) {
//		this.sort = sort;
//	}
//
//	public String getTitle() {
//		return title;
//	}
//
//	public void setTitle(String title) {
//		this.title = title;
//	}
//
//	public ArrayList<Values> getArrayListValues() {
//		return arrayListValues;
//	}
//
//	public void setArrayListValues(ArrayList<Values> arrayListValues) {
//		this.arrayListValues = arrayListValues;
//	}
//
//	private String sort;
//	private String title;
//	private ArrayList<Values> arrayListValues;
//	
//	 
//}
